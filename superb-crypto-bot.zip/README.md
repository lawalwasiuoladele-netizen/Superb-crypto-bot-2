# Superb Crypto Bot

Automated Bybit trading bot. THIS PACKAGE is configured with TESTNET disabled (real trading). Use with caution.

## Files
- server.py (Flask dashboard + SSE)
- bot.py (trading engine using pybit; TESTNET=False)
- templates/index.html (dashboard UI)
- requirements.txt
- render.yaml (.render-build.sh for Render deploy)

## Quick start (local)
1. Python 3.9+
2. pip install -r requirements.txt
3. python server.py
4. Open http://127.0.0.1:5000 to add accounts and start the bot.

## Warning
This bot will place real trades with TESTNET=False. Ensure API keys have correct permissions and you understand the risk of automated trading.
